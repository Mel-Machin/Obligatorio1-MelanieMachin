package org.example;
import org.example.view.IndexView;

public class  Main {
    public static void main(String[] args) {

        IndexView indexView = new IndexView();
        indexView.menuPrincipal();
    }
}
